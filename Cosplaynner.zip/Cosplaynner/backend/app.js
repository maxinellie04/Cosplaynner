// Carico le variabili d'ambiente (.env)
require('dotenv').config();

const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const fs = require('fs');
const path = require('path');

const app = express();

// ====== CARTELLA UPLOADS ======
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}

// ====== MIDDLEWARE DI BASE ======
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// accetto JSON fino a 10MB (per le immagini in base64)
app.use(express.json({ limit: '10mb' }));

// Rendo accessibili le immagini via /uploads/...
app.use('/uploads', express.static(uploadDir));

// ====== SERVE IL FRONTEND (cartella ../frontend) ======
app.use(express.static(path.join(__dirname, '../frontend')));

// Configurazione PostgreSQL
const pool = new Pool({
  user: process.env.DB_USER,      // es: postgres
  host: process.env.DB_HOST,      // es: localhost
  database: process.env.DB_NAME,  // es: nome_del_tuo_db
  password: process.env.DB_PASSWORD,
  port: process.env.DB_PORT,      // es: 5432
});

// DEBUG: verifico che le variabili .env siano lette
console.log("ENV:", {
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD ? '***' : '(vuota)',
  port: process.env.DB_PORT,
  jwtSecret: process.env.JWT_SECRET ? '***' : '(vuoto)'
});

// Test connessione al DB
pool.connect()
  .then(() => console.log("CONNESSO A POSTGRES"))
  .catch(err => console.error("ERRORE CONNESSIONE POSTGRES:", err));

// Funzione per generare JWT
function generateToken(user) {
  return jwt.sign(
    { login: user.login }, // uso il login come identificatore
    process.env.JWT_SECRET,
    { expiresIn: '1h' }
  );
}

// ------------------ ROUTE DI REGISTRAZIONE ------------------
app.post('/register', async (req, res) => {
  try {
    const { login, password } = req.body;

    console.log("Richiesta /register:", { login });

    if (!login || !password) {
      return res.status(400).json({ message: 'Login e password sono obbligatori' });
    }

    const existingUser = await pool.query(
      'SELECT login FROM users WHERE login = $1',
      [login]
    );

    if (existingUser.rows.length > 0) {
      return res.status(409).json({ message: 'Login già esistente' });
    }

    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(password, saltRounds);

    const result = await pool.query(
      'INSERT INTO users (login, password) VALUES ($1, $2) RETURNING login',
      [login, passwordHash]
    );

    const newUser = result.rows[0];
    const token = generateToken(newUser);

    res.status(201).json({
      message: 'Registrazione completata',
      user: { login: newUser.login },
      token: token
    });
  } catch (err) {
    console.error('Errore /register:', err);
    res.status(500).json({ message: 'Errore server' });
  }
});

// ------------------ ROUTE DI LOGIN ------------------
app.post('/login', async (req, res) => {
  try {
    const { login, password } = req.body;

    console.log("Richiesta /login:", { login });

    if (!login || !password) {
      return res.status(400).json({ message: 'Login e password sono obbligatori' });
    }

    const result = await pool.query(
      'SELECT login, password FROM users WHERE login = $1',
      [login]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ message: 'Credenziali non valide' });
    }

    const user = result.rows[0];

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ message: 'Credenziali non valide' });
    }

    const token = generateToken(user);

    res.json({
      message: 'Login effettuato',
      token: token,
      user: { login: user.login }
    });
  } catch (err) {
    console.error('Errore /login:', err);
    res.status(500).json({ message: 'Errore server' });
  }
});

// ------------------ MIDDLEWARE DI AUTENTICAZIONE ------------------
function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1]; // "Bearer xyz"

  if (!token) {
    return res.status(401).json({ message: 'Token mancante' });
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, userDecoded) => {
    if (err) {
      return res.status(403).json({ message: 'Token non valido' });
    }
    req.user = userDecoded; // { login, iat, exp }
    next();
  });
}

// ------------------ /me (ROUTE PROTETTA) ------------------
app.get('/me', authMiddleware, async (req, res) => {
  try {
    console.log("Richiesta /me per:", req.user);

    const result = await pool.query(
      'SELECT login FROM users WHERE login = $1',
      [req.user.login]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Utente non trovato' });
    }

    res.json({ user: result.rows[0] });
  } catch (err) {
    console.error('Errore /me:', err);
    res.status(500).json({ message: 'Errore server' });
  }
});

// ------------------ CREAZIONE COSPLAY + PREZZO + IMMAGINE ------------------
app.post('/cosplays/full', authMiddleware, async (req, res) => {
  const client = await pool.connect();
  try {
    const userLogin = req.user.login;
    const { cosplay_name, prezzo, image_base64 } = req.body;

    if (!cosplay_name || prezzo === undefined || !image_base64) {
      return res.status(400).json({ message: 'cosplay_name, prezzo e image_base64 sono obbligatori' });
    }

    const prezzoNumber = Number(prezzo);
    if (isNaN(prezzoNumber)) {
      return res.status(400).json({ message: 'Prezzo non valido' });
    }

    const existing = await client.query(
      'SELECT cosplay_name FROM cosplays WHERE cosplay_name = $1',
      [cosplay_name]
    );

    if (existing.rows.length > 0) {
      return res.status(409).json({ message: 'Esiste già un cosplay con questo nome' });
    }

    await client.query('BEGIN');

    // 1) Inserisco cosplay
    await client.query(
      'INSERT INTO cosplays (cosplay_name, user_login, descrizione) VALUES ($1, $2, $3)',
      [cosplay_name, userLogin, null]
    );

    // 2) Inserisco prezzo (voce = "Totale")
    await client.query(
      'INSERT INTO prezzi (cosplay_name, voce, costo) VALUES ($1, $2, $3)',
      [cosplay_name, 'Totale', prezzoNumber]
    );

    // 3) Salvo immagine sul disco
    const match = image_base64.match(/^data:(image\/\w+);base64,(.+)$/);
    if (!match) {
      await client.query('ROLLBACK');
      return res.status(400).json({ message: 'Formato immagine non valido' });
    }

    const mimeType = match[1]; // es: image/png
    const ext = mimeType.split('/')[1]; // es: png
    const data = match[2];

    const safeCosplayName = cosplay_name.replace(/\s+/g, "_");
    const filename = `${safeCosplayName}_${Date.now()}.${ext}`;
    const filePath = path.join(uploadDir, filename);
    fs.writeFileSync(filePath, Buffer.from(data, 'base64'));

    const relativePath = `/uploads/${filename}`;

    // 4) Inserisco nella tabella images
    await client.query(
      'INSERT INTO images (cosplay_name, image_path) VALUES ($1, $2)',
      [cosplay_name, relativePath]
    );

    await client.query('COMMIT');

    res.status(201).json({
      message: 'Cosplay creato con successo',
      cosplay_name,
      prezzo: prezzoNumber,
      image_path: relativePath
    });

  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Errore /cosplays/full:', err);
    res.status(500).json({ message: 'Errore server' });
  } finally {
    client.release();
  }
});

// ------------------ LISTA COSPLAY DELL'UTENTE LOGGATO ------------------
app.get('/cosplays', authMiddleware, async (req, res) => {
  try {
    const userLogin = req.user.login;

    const query = `
      SELECT
        c.cosplay_name,
        p.costo AS prezzo_totale,
        i.image_path
      FROM cosplays c
      LEFT JOIN prezzi p
        ON p.cosplay_name = c.cosplay_name
       AND p.voce = 'Totale'
      LEFT JOIN LATERAL (
        SELECT image_path
        FROM images
        WHERE cosplay_name = c.cosplay_name
        ORDER BY image_id ASC
        LIMIT 1
      ) i ON TRUE
      WHERE c.user_login = $1
      ORDER BY c.cosplay_name;
    `;

    const result = await pool.query(query, [userLogin]);

    res.json({ cosplays: result.rows });
  } catch (err) {
    console.error('Errore GET /cosplays:', err);
    res.status(500).json({ message: 'Errore server' });
  }
});

// ------------------ ELIMINAZIONE COSPLAY + RELAZIONI ------------------
app.delete('/cosplays/:cosplayName', authMiddleware, async (req, res) => {
  const client = await pool.connect();
  try {
    const userLogin = req.user.login;
    const { cosplayName } = req.params;

    await client.query('BEGIN');

    // Controllo che il cosplay sia dell'utente
    const check = await client.query(
      'SELECT cosplay_name FROM cosplays WHERE cosplay_name = $1 AND user_login = $2',
      [cosplayName, userLogin]
    );

    if (check.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ message: 'Cosplay non trovato o non tuo' });
    }

    // Recupero immagini per eventuale cancellazione file
    const imagesRes = await client.query(
      'SELECT image_path FROM images WHERE cosplay_name = $1',
      [cosplayName]
    );

    // Cancello righe correlate
    await client.query('DELETE FROM checklist WHERE cosplay_name = $1', [cosplayName]);
    await client.query('DELETE FROM prezzi    WHERE cosplay_name = $1', [cosplayName]);
    await client.query('DELETE FROM images    WHERE cosplay_name = $1', [cosplayName]);
    await client.query('DELETE FROM cosplays  WHERE cosplay_name = $1', [cosplayName]);

    await client.query('COMMIT');

    // Elimino i file fisici (fuori dalla transazione)
    imagesRes.rows.forEach(row => {
      const imgPath = row.image_path;
      if (imgPath && imgPath.startsWith('/uploads/')) {
        const fullPath = path.join(__dirname, imgPath.replace('/uploads/', 'uploads/'));
        if (fs.existsSync(fullPath)) {
          fs.unlink(fullPath, (err) => {
            if (err) console.error('Errore cancellazione file immagine:', fullPath, err);
          });
        }
      }
    });

    res.json({ message: 'Cosplay eliminato con successo' });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('Errore DELETE /cosplays/:cosplayName:', err);
    res.status(500).json({ message: 'Errore server' });
  } finally {
    client.release();
  }
});

// ------------------ CHECKLIST: AGGIUNTA ------------------
app.post('/checklist', authMiddleware, async (req, res) => {
  try {
    const userLogin = req.user.login;
    const { cosplay_name, voce } = req.body;

    if (!cosplay_name || !voce) {
      return res.status(400).json({ message: 'cosplay_name e voce sono obbligatori' });
    }

    // Controllo che il cosplay appartenga all'utente
    const check = await pool.query(
      'SELECT cosplay_name FROM cosplays WHERE cosplay_name = $1 AND user_login = $2',
      [cosplay_name, userLogin]
    );

    if (check.rows.length === 0) {
      return res.status(404).json({ message: 'Cosplay non trovato o non tuo' });
    }

    const result = await pool.query(
      'INSERT INTO checklist (cosplay_name, voce, completato) VALUES ($1, $2, $3) RETURNING checklist_id, cosplay_name, voce, completato',
      [cosplay_name, voce, false]
    );

    res.status(201).json({
      message: 'Voce checklist aggiunta',
      item: result.rows[0]
    });
  } catch (err) {
    console.error('Errore POST /checklist:', err);
    res.status(500).json({ message: 'Errore server' });
  }
});

// ------------------ CHECKLIST: LISTA PER COSPLAY ------------------
app.get('/checklist/:cosplayName', authMiddleware, async (req, res) => {
  try {
    const userLogin = req.user.login;
    const { cosplayName } = req.params;

    const check = await pool.query(
      'SELECT cosplay_name FROM cosplays WHERE cosplay_name = $1 AND user_login = $2',
      [cosplayName, userLogin]
    );

    if (check.rows.length === 0) {
      return res.status(404).json({ message: 'Cosplay non trovato o non tuo' });
    }

    const result = await pool.query(
      'SELECT checklist_id, cosplay_name, voce, completato FROM checklist WHERE cosplay_name = $1 ORDER BY checklist_id ASC',
      [cosplayName]
    );

    res.json({ checklist: result.rows });
  } catch (err) {
    console.error('Errore GET /checklist/:cosplayName:', err);
    res.status(500).json({ message: 'Errore server' });
  }
});

// ------------------ CHECKLIST: TOGGLE COMPLETATO ------------------
app.patch('/checklist/:id/toggle', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      'UPDATE checklist SET completato = NOT completato WHERE checklist_id = $1 RETURNING checklist_id, cosplay_name, voce, completato',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Voce checklist non trovata' });
    }

    res.json({
      message: 'Voce checklist aggiornata',
      item: result.rows[0]
    });
  } catch (err) {
    console.error('Errore PATCH /checklist/:id/toggle:', err);
    res.status(500).json({ message: 'Errore server' });
  }
});

// ------------------ CHECKLIST: ELIMINA VOCE ------------------
app.delete('/checklist/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      'DELETE FROM checklist WHERE checklist_id = $1 RETURNING checklist_id',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Voce checklist non trovata' });
    }

    res.json({ message: 'Voce checklist eliminata' });
  } catch (err) {
    console.error('Errore DELETE /checklist/:id:', err);
    res.status(500).json({ message: 'Errore server' });
  }
});

// ------------------ LISTA COSPLAY PUBBLICA DI UN UTENTE (per condivisione) ------------------
app.get('/public/:login/cosplays', async (req, res) => {
  try {
    const { login } = req.params;

    const query = `
      SELECT
        c.cosplay_name,
        p.costo AS prezzo_totale,
        i.image_path
      FROM cosplays c
      LEFT JOIN prezzi p
        ON p.cosplay_name = c.cosplay_name
       AND p.voce = 'Totale'
      LEFT JOIN LATERAL (
        SELECT image_path
        FROM images
        WHERE cosplay_name = c.cosplay_name
        ORDER BY image_id ASC
        LIMIT 1
      ) i ON TRUE
      WHERE c.user_login = $1
      ORDER BY c.cosplay_name;
    `;

    const result = await pool.query(query, [login]);

    res.json({
      owner: login,
      cosplays: result.rows
    });
  } catch (err) {
    console.error('Errore GET /public/:login/cosplays:', err);
    res.status(500).json({ message: 'Errore server' });
  }
});

// CATCH-ALL per le pagine frontend (Express 5 friendly)
app.get(/.*/, (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend', 'index.html'));
});


// ------------------ AVVIO SERVER ------------------
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server avviato su http://localhost:${PORT}`);
});
