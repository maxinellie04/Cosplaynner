// =======================
// CONFIG
// =======================

// Usa lo stesso origin del sito (es: http://localhost:3000)
const API_URL = window.location.origin;

// Chiave usata per salvare il token nel localStorage
const tokenKey = 'authToken';

// =======================
// RIFERIMENTI ELEMENTI DOM
// =======================

// Form e messaggi login/register (solo in quelle pagine)
const registerForm   = document.getElementById('register-form');
const loginForm      = document.getElementById('login-form');
const registerMsg    = document.getElementById('register-message');
const loginMsg       = document.getElementById('login-message');

// (se li userai in futuro)
const meSection      = document.getElementById('me-section');
const meBtn          = document.getElementById('me-btn');
const meOutput       = document.getElementById('me-output');

// Bottoni sidebar
const homeLoginBtn    = document.getElementById('login-btn');    // "Accedi" in home, "Home" in login/register
const homeRegisterBtn = document.getElementById('register-btn'); // Solo in home
const logoutBtn       = document.getElementById('logout-btn');   // Solo in home

// Sezioni home
const welcomeSection   = document.getElementById('welcomeSection');
const dashboardSection = document.getElementById('dashboardSection');

// Dashboard: cosplay
const addCosplayBtn        = document.getElementById('addCosplayBtn');
const cosplayFormContainer = document.getElementById('cosplayFormContainer');
const cosplayForm          = document.getElementById('cosplayForm');
const cosplayNameInput     = document.getElementById('cosplayNameInput');
const cosplayPriceInput    = document.getElementById('cosplayPriceInput');
const cosplayImageInput    = document.getElementById('cosplayImageInput');
const cosplayMessage       = document.getElementById('cosplayMessage');

const refreshCosplaysBtn = document.getElementById('refreshCosplaysBtn');
const cosplayList        = document.getElementById('cosplayList');


// =======================
// FUNZIONE UI IN BASE AL LOGIN
// =======================
function updateAuthUI() {
  const token = localStorage.getItem(tokenKey);

  // Sezione "me" eventuale
  if (meSection) {
    meSection.style.display = token ? 'block' : 'none';
  }

  // In home (index): nascondi / mostra login e register
  if (homeLoginBtn && (welcomeSection || dashboardSection)) {
    // qui login-btn significa "Accedi"
    homeLoginBtn.style.display = token ? 'none' : 'inline-block';
  }
  if (homeRegisterBtn) {
    homeRegisterBtn.style.display = token ? 'none' : 'inline-block';
  }

  // Logout visibile solo se loggato
  if (logoutBtn) {
    logoutBtn.style.display = token ? 'inline-block' : 'none';
  }

  // In home: dashboard vs welcome
  if (dashboardSection) {
    dashboardSection.style.display = token ? 'block' : 'none';
  }
  if (welcomeSection) {
    welcomeSection.style.display = token ? 'none' : 'block';
  }

  // Se non loggato, nascondo eventuale form cosplay
  if (!token && cosplayFormContainer) {
    cosplayFormContainer.style.display = 'none';
  }

  // Se loggato e siamo in dashboard, carico i cosplay
  if (token && dashboardSection && cosplayList) {
    loadCosplays();
  }
}

// Chiamata iniziale
updateAuthUI();


// =======================
// NAVIGAZIONE HOME / LOGIN / REGISTER
// =======================

// login-btn:
// - in home = "Accedi" => vai su login.html
// - in login/register = "Home" => vai su index.html
if (homeLoginBtn) {
  homeLoginBtn.addEventListener('click', () => {
    if (welcomeSection || dashboardSection) {
      // siamo in index
      window.location.href = 'login.html';
    } else {
      // siamo in login/register
      window.location.href = 'index.html';
    }
  });
}

// register-btn esiste solo in home: porta a register.html
if (homeRegisterBtn) {
  homeRegisterBtn.addEventListener('click', () => {
    window.location.href = 'register.html';
  });
}


// =======================
// REGISTRAZIONE
// =======================
if (registerForm) {
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (registerMsg) {
      registerMsg.textContent = '';
      registerMsg.className = 'message';
    }

    const login = document.getElementById('register-login').value.trim();
    const password = document.getElementById('register-password').value;

    try {
      const res = await fetch(`${API_URL}/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ login, password })
      });

      const data = await res.json();

      if (!res.ok) {
        if (registerMsg) {
          registerMsg.textContent = data.message || 'Errore in registrazione';
          registerMsg.classList.add('error');
        }
        return;
      }

      // Salvo token e login
      if (data.token) {
        localStorage.setItem(tokenKey, data.token);
        localStorage.setItem('userLogin', data.user.login);
        updateAuthUI();
        window.location.href = 'index.html';
        return;
      }

      if (registerMsg) {
        registerMsg.textContent = 'Registrazione completata!';
        registerMsg.classList.add('success');
      }

      registerForm.reset();
    } catch (err) {
      console.error(err);
      if (registerMsg) {
        registerMsg.textContent = 'Errore di rete';
        registerMsg.classList.add('error');
      }
    }
  });
}


// =======================
// LOGIN
// =======================
if (loginForm) {
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (loginMsg) {
      loginMsg.textContent = '';
      loginMsg.className = 'message';
    }

    const login = document.getElementById('login-login').value.trim();
    const password = document.getElementById('login-password').value;

    try {
      const res = await fetch(`${API_URL}/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ login, password })
      });

      const data = await res.json();

      if (!res.ok) {
        if (loginMsg) {
          loginMsg.textContent = data.message || 'Errore di login';
          loginMsg.classList.add('error');
        }
        return;
      }

      if (data.token) {
        localStorage.setItem(tokenKey, data.token);
        localStorage.setItem('userLogin', data.user.login);
        updateAuthUI();
        window.location.href = 'index.html';
        return;
      }

      if (loginMsg) {
        loginMsg.textContent = 'Login effettuato!';
        loginMsg.classList.add('success');
      }

      loginForm.reset();
    } catch (err) {
      console.error(err);
      if (loginMsg) {
        loginMsg.textContent = 'Errore di rete';
        loginMsg.classList.add('error');
      }
    }
  });
}


// =======================
// /me (se mai vorrai usarla in futuro)
// =======================
if (meBtn) {
  meBtn.addEventListener('click', async () => {
    const token = localStorage.getItem(tokenKey);
    if (!token) {
      if (meOutput) meOutput.textContent = 'Non sei loggato.';
      return;
    }

    try {
      const res = await fetch(`${API_URL}/me`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      const data = await res.json();

      if (!res.ok) {
        if (meOutput) {
          meOutput.textContent = `Errore: ${data.message || 'richiesta fallita'}`;
        }
        return;
      }

      if (meOutput) {
        meOutput.textContent = JSON.stringify(data.user, null, 2);
      }
    } catch (err) {
      console.error(err);
      if (meOutput) meOutput.textContent = 'Errore di rete';
    }
  });
}


// =======================
// LOGOUT
// =======================
if (logoutBtn) {
  logoutBtn.addEventListener('click', () => {
    localStorage.removeItem(tokenKey);
    localStorage.removeItem('userLogin');
    if (meOutput) meOutput.textContent = '';
    updateAuthUI();
    window.location.href = 'index.html';
  });
}


// =======================
// DASHBOARD: FORM NUOVO COSPLAY
// =======================

// Mostra/nascondi form "nuovo cosplay"
if (addCosplayBtn && cosplayFormContainer) {
  addCosplayBtn.addEventListener('click', () => {
    const isVisible = cosplayFormContainer.style.display === 'block';
    cosplayFormContainer.style.display = isVisible ? 'none' : 'block';
  });
}

// Submit del form nuovo cosplay
if (cosplayForm) {
  cosplayForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (cosplayMessage) cosplayMessage.textContent = '';

    const token = localStorage.getItem(tokenKey);
    if (!token) {
      if (cosplayMessage) cosplayMessage.textContent = 'Devi essere loggato.';
      return;
    }

    const cosplayName = cosplayNameInput.value.trim();
    const priceStr    = cosplayPriceInput.value.trim();
    const file        = cosplayImageInput.files[0];

    if (!cosplayName || !priceStr || !file) {
      if (cosplayMessage) cosplayMessage.textContent = 'Compila tutti i campi.';
      return;
    }

    const prezzo = parseFloat(priceStr);
    if (isNaN(prezzo)) {
      if (cosplayMessage) cosplayMessage.textContent = 'Prezzo non valido.';
      return;
    }

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64data = reader.result; // "data:image/xxx;base64,AAA..."

      try {
        const res = await fetch(`${API_URL}/cosplays/full`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({
            cosplay_name: cosplayName,
            prezzo: prezzo,
            image_base64: base64data
          })
        });

        const data = await res.json();

        if (!res.ok) {
          if (cosplayMessage) cosplayMessage.textContent = data.message || 'Errore nella creazione del cosplay';
          return;
        }

        if (cosplayMessage) cosplayMessage.textContent = 'Cosplay creato con successo!';
        cosplayForm.reset();
        cosplayFormContainer.style.display = 'none';

        // ricarico la lista dei cosplay
        loadCosplays();

      } catch (err) {
        console.error(err);
        if (cosplayMessage) cosplayMessage.textContent = 'Errore di rete.';
      }
    };

    reader.readAsDataURL(file);
  });
}


// =======================
// DASHBOARD: CARICAMENTO LISTA COSPLAY
// =======================
async function loadCosplays() {
  const token = localStorage.getItem(tokenKey);
  if (!token || !cosplayList) return;

  cosplayList.innerHTML = '';

  try {
    const res = await fetch(`${API_URL}/cosplays`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    const data = await res.json();

    if (!res.ok) {
      cosplayList.textContent = data.message || 'Errore nel caricamento dei cosplay.';
      return;
    }

    if (!data.cosplays || data.cosplays.length === 0) {
      cosplayList.textContent = 'Non hai ancora creato nessun cosplay.';
      return;
    }

    data.cosplays.forEach(c => {
      const card = document.createElement('div');
      card.className = 'cosplay-card';

      const title = document.createElement('h3');
      title.textContent = c.cosplay_name;
      card.appendChild(title);

      const price = document.createElement('p');
      if (c.prezzo_totale !== null && c.prezzo_totale !== undefined) {
        price.textContent = `Prezzo: € ${c.prezzo_totale}`;
      } else {
        price.textContent = 'Prezzo: non impostato';
      }
      card.appendChild(price);

      if (c.image_path) {
        const img = document.createElement('img');
        img.src = `${API_URL}${c.image_path}`;
        img.alt = c.cosplay_name;
        img.style.maxWidth = '100%';
        img.style.borderRadius = '6px';
        img.style.marginTop = '8px';
        card.appendChild(img);
      }

      // --- BOTTONI: ELIMINA COSPLAY ---
      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = 'Elimina cosplay';
      deleteBtn.setAttribute('data-role', 'delete-cosplay');
      deleteBtn.style.marginTop = '8px';
      deleteBtn.addEventListener('click', () => {
        if (confirm(`Sei sicuro di voler eliminare il cosplay "${c.cosplay_name}"?\nVerranno cancellate anche immagini, prezzi e checklist.`)) {
          deleteCosplay(c.cosplay_name);
        }
      });
      card.appendChild(deleteBtn);

      // --- SEZIONE CHECKLIST ---
      const checklistSection = document.createElement('div');
      checklistSection.className = 'checklist-container';

      const checklistTitle = document.createElement('h4');
      checklistTitle.textContent = 'Checklist';
      checklistSection.appendChild(checklistTitle);

      const checklistList = document.createElement('ul');
      checklistList.style.listStyle = 'none';
      checklistList.style.padding = '0';
      checklistSection.appendChild(checklistList);

      // Form per aggiungere una voce
      const checklistForm = document.createElement('div');
      // qui usiamo la CLASSE che il CSS stylizza (.add-checklist-row)
      checklistForm.className = 'add-checklist-row';

      const checklistInput = document.createElement('input');
      checklistInput.type = 'text';
      checklistInput.placeholder = 'Nuova voce (es. parrucca, armatura...)';

      const checklistAddBtn = document.createElement('button');
      checklistAddBtn.textContent = 'Aggiungi';

      checklistForm.appendChild(checklistInput);
      checklistForm.appendChild(checklistAddBtn);
      checklistSection.appendChild(checklistForm);

      // Gestione click "Aggiungi"
      checklistAddBtn.addEventListener('click', async () => {
        const voce = checklistInput.value.trim();
        if (!voce) return;

        await addChecklistItem(c.cosplay_name, voce);
        checklistInput.value = '';
        await loadChecklist(c.cosplay_name, checklistList);
      });

      // Carico checklist per questo cosplay
      loadChecklist(c.cosplay_name, checklistList);

      card.appendChild(checklistSection);

      cosplayList.appendChild(card);
    });

  } catch (err) {
    console.error('Errore fetch /cosplays:', err);
    cosplayList.textContent = 'Errore di rete nel caricamento dei cosplay.';
  }
}

if (refreshCosplaysBtn) {
  refreshCosplaysBtn.addEventListener('click', () => {
    loadCosplays();
  });
}


// =======================
// CHECKLIST: FUNZIONI FRONTEND
// =======================
async function loadChecklist(cosplayName, listElement) {
  const token = localStorage.getItem(tokenKey);
  if (!token) return;

  listElement.innerHTML = '';

  try {
    const res = await fetch(`${API_URL}/checklist/${encodeURIComponent(cosplayName)}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    const data = await res.json();

    if (!res.ok) {
      const li = document.createElement('li');
      li.textContent = data.message || 'Errore caricamento checklist.';
      listElement.appendChild(li);
      return;
    }

    if (!data.checklist || data.checklist.length === 0) {
      const li = document.createElement('li');
      li.textContent = 'Nessuna voce nella checklist.';
      listElement.appendChild(li);
      return;
    }

    data.checklist.forEach(item => {
      const li = document.createElement('li');
      li.className = 'checklist-item';

      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = item.completato;

      const label = document.createElement('span');
      label.textContent = item.voce;
      label.className = 'text';
      if (item.completato) {
        label.classList.add('completed');
      }

      checkbox.addEventListener('change', async () => {
        await toggleChecklistItem(item.checklist_id);
        // Aggiorno solo stile, senza ricaricare tutto
        if (checkbox.checked) {
          label.classList.add('completed');
        } else {
          label.classList.remove('completed');
        }
      });

      const deleteBtn = document.createElement('button');
      deleteBtn.textContent = 'X';

      deleteBtn.addEventListener('click', async () => {
        if (confirm(`Eliminare la voce "${item.voce}"?`)) {
          await deleteChecklistItem(item.checklist_id);
          await loadChecklist(cosplayName, listElement);
        }
      });

      li.appendChild(checkbox);
      li.appendChild(label);
      li.appendChild(deleteBtn);

      listElement.appendChild(li);
    });

  } catch (err) {
    console.error('Errore loadChecklist:', err);
    const li = document.createElement('li');
    li.textContent = 'Errore di rete caricando la checklist.';
    listElement.appendChild(li);
  }
}

async function addChecklistItem(cosplayName, voce) {
  const token = localStorage.getItem(tokenKey);
  if (!token) return;

  try {
    const res = await fetch(`${API_URL}/checklist`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ cosplay_name: cosplayName, voce })
    });

    const data = await res.json();
    if (!res.ok) {
      console.error('Errore aggiunta checklist:', data);
    }
  } catch (err) {
    console.error('Errore rete aggiunta checklist:', err);
  }
}

async function toggleChecklistItem(id) {
  const token = localStorage.getItem(tokenKey);
  if (!token) return;

  try {
    const res = await fetch(`${API_URL}/checklist/${id}/toggle`, {
      method: 'PATCH',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (!res.ok) {
      const data = await res.json();
      console.error('Errore toggle checklist:', data);
    }
  } catch (err) {
    console.error('Errore rete toggle checklist:', err);
  }
}

async function deleteChecklistItem(id) {
  const token = localStorage.getItem(tokenKey);
  if (!token) return;

  try {
    const res = await fetch(`${API_URL}/checklist/${id}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (!res.ok) {
      const data = await res.json();
      console.error('Errore delete checklist:', data);
    }
  } catch (err) {
    console.error('Errore rete delete checklist:', err);
  }
}


// =======================
// COSPLAY: ELIMINAZIONE
// =======================
async function deleteCosplay(cosplayName) {
  const token = localStorage.getItem(tokenKey);
  if (!token) return;

  try {
    const res = await fetch(`${API_URL}/cosplays/${encodeURIComponent(cosplayName)}`, {
      method: 'DELETE',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    const data = await res.json();

    if (!res.ok) {
      alert(data.message || 'Errore nella cancellazione del cosplay');
      return;
    }

    alert('Cosplay eliminato con successo.');
    loadCosplays();
  } catch (err) {
    console.error('Errore deleteCosplay:', err);
    alert('Errore di rete durante la cancellazione del cosplay.');
  }
}
